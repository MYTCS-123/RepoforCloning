
def Addition(a,b):
    c=a+b
    print("Sum of ",a," and ",b," is ",c)

def Cube(x):
    return x*x*x





Addition(10,20)
Addition(34,56)

res=Cube(5)
print("Cube(5) = ",res)

print("Cube(9) = ",Cube(9))
