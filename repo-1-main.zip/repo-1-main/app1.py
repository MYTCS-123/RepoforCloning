
print("Welcome To Python World.")
print("This is my First Python Program")
