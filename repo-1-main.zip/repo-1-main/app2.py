a,b = 10,20
c=a+b
print("Sum of ",a," and ",b," is ",c)
c=a-b
print("Sub of ",a," and ",b," is ",c)
c=a*b
print("Mul of ",a," and ",b," is ",c)
c=a/b
print("Div of ",a," and ",b," is ",c)
